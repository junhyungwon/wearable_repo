#!/bin/sh
# Short-Description: Remove /etc/nologin at boot
# Description:       This script detect cold-plug usb device
#                    already plugged in and the usb controller
#                    driver isn't a module

# Check device modalias
if [ ! -f /sys/bus/usb/devices/1-1/1-1\:1.0/bInterfaceClass ]; then
	exit 1
fi

modload() {
	#$1 --> *.ko, remove .ko or basename $1 .ko
	module=$(echo $1 | cut -d '.' -f1)
#	echo "$module" > /dev/console
	if [ ! -d /sys/module/$module ]; then
		echo "Try load $@" > /dev/console
		/sbin/insmod /lib/modules/$@ > /dev/null 2>&1
		# wait
		#sleep 1
	fi
}

CLASS=`cat /sys/bus/usb/devices/1-1/1-1\:1.0/bInterfaceClass`

# communication class
if [ $CLASS == "ff" ]; then
	# Get USB Vendor ID
	VID=`cat /sys/bus/usb/devices/1-1/idVendor`
	# Get USB Product ID
	PID=`cat /sys/bus/usb/devices/1-1/idProduct`

	if [[ $VID == "0bda" && $PID == "a811" ]]; then
		modload 8821au.ko
	fi
	
	if [[ $VID == "0bda" && $PID == "b812" ]]; then
		modload 88x2bu.ko
	fi
fi

: exit 0
