#!/bin/sh

DESC="HOSTAP Daemon"
DEFAULT_IP="192.168.0.1"
CONFIG_FILE="/etc/hostapd.conf"
DAEMON="/usr/sbin/hostapd"

test -f $DAEMON || exit 0

case "$1" in
    start)
	echo "Starting $DESC: "
	
	ARGS="$CONFIG_FILE -B"
	$DAEMON $ARGS
	
	ifconfig wlan0 up
	ifconfig -a | grep -n 'wlan0' | grep '\.'
	
	if [ $? ]; then
		ip_addr=`ifconfig wlan0 | grep 'inet addr' | cut -f2 -d':' | cut -f1 -d' '`
		
		if [ "${ip_addr}" = "" ]; then
			# Set default ip address
			ifconfig wlan0 ${DEFAULT_IP} up
		fi
	fi
	echo "$NAME."
	;;
    stop)
	echo "Stopping $DESC: "
	$DAEMON -S $CONFIG_FILE
#	killall `basename $DAEMON`
	ifconfig wlan0 down
	echo "$NAME."
	;;
    restart)
	$0 stop
	$0 start $2
	;;
    *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
	;;
esac

exit 0
