#!/bin/sh
#
# Start logging
#
log_dir="/mmc/log"

makelogdir()
{
    ! test -d $log_dir && mkdir -p $log_dir
}

case "$1" in
  start)
	echo -n "Starting logging: "
    #create log directory
    cat /proc/mounts | awk '{print $1}' | grep -q "/dev/mmcblk0p1" | makelogdir
#	start-stop-daemon -b -S -q -m -p /var/run/syslogd.pid --exec /sbin/syslogd -- -n
#	start-stop-daemon -b -S -q -m -p /var/run/syslogd.pid --exec /sbin/syslogd -- -n -O /media/nand/message
	start-stop-daemon -b -S -q -m -p /var/run/syslogd.pid --exec /sbin/syslogd -- -n -O /mmc/log/message.log
#	start-stop-daemon -b -S -q -m -p /var/run/klogd.pid --exec /sbin/klogd -- -n
	echo "OK"
	;;
  stop)
	echo -n "Stopping logging: "
	start-stop-daemon -K -q -p /var/run/syslogd.pid
#	start-stop-daemon -K -q -p /var/run/klogd.pid
	echo "OK"
	;;
  restart|reload)
	;;
  *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?
