#!/bin/sh
#
# Start logging
#
log_dir="/media/nand/log"
DAEMON="syslogd"
PIDFILE="/var/run/$DAEMON.pid"

makelogdir()
{
    ! test -d $log_dir && mkdir -p $log_dir
}

# BusyBox' syslogd does not create a pidfile, so pass "-n" in the command line
# and use "-m" to instruct start-stop-daemon to create one.
start() {
	printf 'Starting %s: ' "$DAEMON"
	#create log directory
    #cat /proc/mounts | awk '{print $1}' | grep -q "/dev/mmcblk0p1" | makelogdir
    makelogdir
	# shellcheck disable=SC2086 # we need the word splitting
	start-stop-daemon -b -S -q -x "/sbin/$DAEMON" \
		-- -n $SYSLOGD_ARGS -O /media/nand/log/message.log
	status=$?
	if [ "$status" -eq 0 ]; then
		echo "OK"
	else
		echo "FAIL"
	fi
	return "$status"
}

stop() {
	printf 'Stopping %s: ' "$DAEMON"
	killall "$DAEMON"
	status=$?
	if [ "$status" -eq 0 ]; then
		echo "OK"
	else
		echo "FAIL"
	fi
	return "$status"
}

restart() {
	stop
	sleep 1
	start
}

case "$1" in
	start|stop|restart)
		"$1";;
	reload)
		# Restart, since there is no true "reload" feature.
		restart;;
	*)
		echo "Usage: $0 {start|stop|restart|reload}"
		exit 1
esac
