#!/bin/sh

telnetd=/usr/sbin/telnetd

test -x "$telnetd" || exit 0

case "$1" in
  start)
    echo "Starting telnet daemon..."
    $telnetd -l /bin/sh
    ;;
  stop)
    ;;
  *)
    echo "Usage: /etc/init.d/telnetd {start|stop}"
    exit 1
esac

exit 0
