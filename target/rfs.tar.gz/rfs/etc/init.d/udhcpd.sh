#!/bin/sh
#
# udhcpd init script to start/stop udhcpd.
#
DAEMON=/usr/sbin/udhcpd
NAME=udhcpd
DESC="DHCP Daemon"
ARGS="/etc/udhcpd.conf"

test -f $DAEMON || exit 0

set -e

if [ ! -e $ARGS ]; then
	eval "echo No config file at $ARGS"
	exit 0
fi

case "$1" in
    start)
	echo "Starting $DESC: "
	$DAEMON $ARGS
	;;
    stop)
	echo "Stopping $DESC: "
	killall `basename $DAEMON`
	echo "$NAME."
	;;
    restart)
	$0 stop
	$0 start
	;;
    *)
	echo "Usage: $0 {start|stop|restart}"
	exit 1
	;;
esac

exit 0

