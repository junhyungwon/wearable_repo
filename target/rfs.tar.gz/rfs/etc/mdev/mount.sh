#!/bin/sh
#
# Called from udev
# Attemp to mount any added block devices
# and remove any removed devices
#

test -z "$DEVNAME" && DEVNAME=$MDEV

MOUNT="/bin/mount"
PMOUNT="/usr/bin/pmount"
UMOUNT="/bin/umount"
name="`basename "$DEVNAME"`"
mount_dir="/media/$name"
FSCK="/usr/sbin/e2fsck"

logger "auto mount script run! devname=$DEVNAME, action=$ACTION"

automount()
{
	if [ "${name:0:6}" = "mmcblk" ]; then
		mount_dir="/mmc"
	fi

	# Get fs type from block (remove PARTUUID)
	FS_TYPE="`blkid "$DEVNAME" | awk 'BEGIN{FS="TYPE";RS="\n"} {print $2}' | sed -e 's/=//' -e 's/"//g' | awk '{print $1}'`"

	! test "$FS_TYPE" && return
	! test -d $mount_dir && mkdir -p $mount_dir

	if [ $FS_TYPE == "exfat" ]; then
		return
	fi

	if ! $MOUNT -t $FS_TYPE  $DEVNAME $mount_dir
	then
		rm_dir $mount_dir
	else
		touch "/tmp/.automount-$name"
		echo $BUS_TYPE > "/tmp/.automount-$name"
	fi
}

rm_dir()
{
	# We do not want to rm -r populated directories
	if test "`find "$1" | wc -l | tr -d " "`" -lt 2 -a -d "$1"
	then
		! test -z "$1" && rm -r "$1"
		rm /tmp/.automount-$name
	else
		logger "mount.sh/automount" "Not removing non-empty directory [$1]"
	fi
}

if [ "$ACTION" = "add" ] && [ -n "$DEVNAME" ]; then

	if [ -x "$PMOUNT" ]; then
		$PMOUNT $DEVNAME 2> /dev/null
	elif [ -x $MOUNT ]; then
    		$MOUNT $DEVNAME 2> /dev/null
	fi

	# If the device isn't mounted at this point, it isn't configured in fstab
	# 20061107: Small correction: The rootfs partition may be called just "rootfs" and not by
	# 	    its true device name so this would break. If the rootfs is mounted on two places
	#	    during boot, it confuses the heck out of fsck. So Im auto-adding the root-partition
	#	    to /etc/udev/mount.blacklist via postinst

	cat /proc/mounts | awk '{print $1}' | grep -q "$DEVNAME" || automount
fi

if [ "$ACTION" = "remove" ] && [ -x "$UMOUNT" ] && [ -n "$DEVNAME" ]; then
	for mnt in `cat /proc/mounts | grep "$DEVNAME" | cut -f 2 -d " " `
	do
		$UMOUNT -l $mnt
	done

	# Remove empty directories from auto-mounter
	test -e "/tmp/.automount-$name" && rm_dir $mount_dir
fi
