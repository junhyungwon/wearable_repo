#!/bin/sh
#
# Attemp to mount any added block devices
#

test -z "$DEVNAME" && DEVNAME=$MDEV

mount_dir="/media/nand"
num="0"

block=`echo "$MDEV" | sed 's/[^0-9]//g'`

if [ "$ACTION" = "add" ] && [ -n "$DEVNAME" ]; then
	/usr/sbin/ubiattach /dev/ubi_ctrl -m $block -O 2048

	while [ -e /dev/ubi"$num" ]
	do
		num=`expr $num + 1`
	done

	# last number
	num=`expr $num - 1`

	# reserved for bad sector management
	! test -c /dev/ubi"$num"_0 && /usr/sbin/ubimkvol /dev/ubi"$num" -N ubifs_data -s 40MiB
	! test -d $mount_dir && mkdir -p $mount_dir

	if ! /bin/mount -t ubifs ubi"$num":ubifs_data $mount_dir
	then
		# retry ubiformat attach
		/usr/sbin/ubidetach /dev/ubi_ctrl -d "$num"
		/usr/sbin/ubiformat /dev/mtd6 -y -q -s 2048 -O 2048
		/usr/sbin/ubiattach /dev/ubi_ctrl -m 6 -O 2048

		! test -c /dev/ubi"$num"_0 && /usr/sbin/ubimkvol /dev/ubi"$num" -N ubifs_data -s 40MiB

		/bin/mount -t ubifs ubi"$num":ubifs_data $mount_dir
	fi
fi

# mtdblock is not required.
if [ "$ACTION" = "remove" ] && [ -n "$DEVNAME" ]; then
	echo "remove" > /dev/console
fi
