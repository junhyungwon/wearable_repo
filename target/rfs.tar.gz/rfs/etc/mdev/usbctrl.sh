

#######################################################################################################################
#
# MDEV USB control helper
#
#######################################################################################################################

for path in $(find /sys/devices -name "$MDEV" 2>/dev/null); do
	DEVPATH=${path#/sys};
done
MODALIAS=$(cat /sys${DEVPATH}/device/1-1\:1.0/modalias 2>/dev/null)
TYPE=$(echo $MODALIAS | printf '%d/%d/%d' $(sed 's/.*d[0-9]\{4\}//;s/ic.*//;s/[dscp]\+/ 0x/g'))
PRODUCT=$(echo $MODALIAS | sed 's!^usb:\(.*\)dc.*!\1!;s![vpd]!/!g;s!/0\{1,3\}!/!g;s!^/!!;y!ABCDEF!abcdef!')
INTERFACE=$(echo $MODALIAS | printf '%d/%d/%d' $(sed 's/.*dp[0-F]\{2\}//;s/[iscp]\+/ 0x/g'))

#echo $ACTION > /dev/console
#echo $INTERFACE > /dev/console

# Use class code info from Interface Descriptors
#[ 0 -eq "${TYPE%%/*}" ] && TYPE=$INTERFACE

modload() {
	if [ ! -d /sys/module/$1 ]; then
		echo "Try load $@" > /dev/console
		insmod /opt/fit/kermod/$@
	fi
}

if [ $ACTION == "add" ]; then
	# Get USB Vendor ID and Product ID
#	VID=`cat /sys/bus/usb/devices/1-1/idVendor`
#	PID=`cat /sys/bus/usb/devices/1-1/idProduct`

	case $INTERFACE in
        2/*)
            echo "cdc rndis_host" > /dev/console
            modload rndis_host.ko
            ;;
        224/*)
			echo "may be rndis_host" > /dev/console
			modload rndis_host.ko
			;;
	    239/*)
			echo "misc rndis_host" > /dev/console
			modload rndis_host.ko
			;;
	    255/*)
#			echo "wireless device" > /dev/console
			;;
	esac	
fi

if [ $ACTION == "remove" ]; then
	if [ -d /sys/module/rndis_host ]; then
#		echo "remove rndis_host" > /dev/console
		rmmod rndis_host
	fi
fi
