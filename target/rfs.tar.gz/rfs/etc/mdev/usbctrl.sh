

#######################################################################################################################
#
# MDEV USB control helper
#
#######################################################################################################################

for path in $(find /sys/devices -name "$MDEV" 2>/dev/null); do
	DEVPATH=${path#/sys};
done
MODALIAS=$(cat /sys${DEVPATH}/device/1-1\:1.0/modalias 2>/dev/null)
TYPE=$(echo $MODALIAS | printf '%d/%d/%d' $(sed 's/.*d[0-9]\{4\}//;s/ic.*//;s/[dscp]\+/ 0x/g'))
PRODUCT=$(echo $MODALIAS | sed 's!^usb:\(.*\)dc.*!\1!;s![vpd]!/!g;s!/0\{1,3\}!/!g;s!^/!!;y!ABCDEF!abcdef!')
INTERFACE=$(echo $MODALIAS | printf '%d/%d/%d' $(sed 's/.*dp[0-F]\{2\}//;s/[iscp]\+/ 0x/g'))

#echo $ACTION > /dev/console
#echo $INTERFACE > /dev/console

# Use class code info from Interface Descriptors
#[ 0 -eq "${TYPE%%/*}" ] && TYPE=$INTERFACE
device_in() {
	if [ -e /etc/usb_modeswitch.d/"$1:$2" ]; then
		return 1
	fi

	return 0
}

modload() {
	#$1 --> rndis_host.ko, remove .ko or basename $1 .ko
	module=$(echo $1 | cut -d '.' -f1)
#	echo "$module" > /dev/console
	if [ ! -d /sys/module/$module ]; then
		echo "Try load $@" > /dev/console
		/sbin/insmod /opt/fit/kermod/$@
	fi
}

wlanload() {
	module=$(echo $1 | cut -d '.' -f1)
	if [ ! -d /sys/module/$module ]; then
		echo "Try load $@" > /dev/console
		/sbin/insmod /lib/modules/$@ > /dev/null 2>&1
        sleep 1
        /sbin/ifconfig wlan0 up
	fi
}

if [ $ACTION == "add" ]; then
	#echo "$INTERFACE" > /dev/console
	case $INTERFACE in
        2/12/7)
            echo "Bypass rndis_host" > /dev/console
			;;
		2/*)
			#2/6/0
            echo "cdc rndis_host" > /dev/console
            modload rndis_host.ko
            ;;
        224/*)
			echo "may be rndis_host" > /dev/console
			modload rndis_host.ko
			;;
	    239/*)
			echo "misc rndis_host" > /dev/console
			modload rndis_host.ko
			;;
	    255/*)
			#echo "wireless device" > /dev/console 
			# Get USB Vendor ID and Product ID
			v_id=`cat /sys/bus/usb/devices/1-1/idVendor`
			p_id=`cat /sys/bus/usb/devices/1-1/idProduct`
			if [[ $v_id == "0bda" && $p_id == "a811" ]]; then
				wlanload 8821au.ko
			elif [[ $v_id == "0bda" && $p_id == "b812" ]]; then
				wlanload 88x2bu.ko
			elif [[ $v_id == "1bbb" && $p_id == "0192" ]]; then
				echo "may be rndis_host" > /dev/console
				modload rndis_host.ko
			fi
			;;
		8/*)
			echo "mass_storage device" > /dev/console
			# required usb modeswitch
			# errexit off
			# Get USB Vendor ID and Product ID
			v_id=`cat /sys/bus/usb/devices/1-1/idVendor`
			p_id=`cat /sys/bus/usb/devices/1-1/idProduct`
			set +e
			device_in $v_id $p_id
			if [ "$?" = "1" ]; then
				if [[ $v_id = "1bbb" && $p_id = "f000" ]]; then
					/usr/sbin/usb_modeswitch -v "0x$v_id" -p "0x$p_id" -Q -c /etc/usb_modeswitch.d/$v_id\:$p_id > /dev/null 2>&1
					exit 0
				fi
			fi
		
	esac	
fi

if [ $ACTION == "remove" ]; then
	# remove rndis_host
	if [ -d /sys/module/rndis_host ]; then
		echo "remove rndis_host" > /dev/console
		/sbin/rmmod rndis_host
	# remove 8812au
	elif [ -d /sys/module/8821au ]; then
		echo "remove 8821au" > /dev/console
		/sbin/rmmod 8821au
	# remove 88x2bu
	elif [ -d /sys/module/88x2bu ]; then
		echo "remove 88x2bu" > /dev/console
		/sbin/rmmod 88x2bu
	fi
fi
