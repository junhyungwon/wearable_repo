#!/bin/sh

# start application -----------------------------
echo -e "start application"

app_dir="fit"

if [ -x ./$app_dir/demo.sh ]; then
	cd ./$app_dir/
	./demo.sh
fi

