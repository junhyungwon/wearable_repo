#!/bin/sh
[ -z "$1" ] && echo "Error: should be called from sslvpnd" && exit 1
VPNHOME=$sv_g_home
$VPNHOME/busybox ip route del $1
$VPNHOME/busybox ip route del $1
GW=`$VPNHOME/busybox ip route | $VPNHOME/busybox grep -v tap | $VPNHOME/busybox grep -m 1 "default.*via" | $VPNHOME/busybox awk -F via '{print $2}'` 
if [ "$GW" != "" ]; then                
$VPNHOME/busybox ip route add $1 via $GW
else
GW=`$VPNHOME/busybox ip route | $VPNHOME/busybox grep -v tap | $VPNHOME/busybox grep -m 1 "default.*dev" | $VPNHOME/busybox awk -F dev '{print $2}'`
$VPNHOME/busybox ip route add $1 dev $GW
fi
