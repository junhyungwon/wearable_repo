#!/bin/sh
[ -z "$1" ] && echo "Error: should be called from sslvpnd" && exit 1
VPNHOME=$sv_g_home
DCUBE_ID=$sv_g_id
#IF_NUM=`$VPNHOME/busybox echo -n $1 | $VPNHOME/busybox sed "s/tap//g"`
if [ -n "$DCUBE_ID" ] ; then
	$VPNHOME/busybox udhcpc -t 3 -n -q -i $1 -O msstaticroutes -x 61:00$($VPNHOME/busybox echo -n $DCUBE_ID | $VPNHOME/busybox od -w64 -A n -t x1 | $VPNHOME/busybox sed "s/ //g") -s $VPNHOME/default.script;if [ ! $? -eq 0 ]; then ifconfig $1 down up; fi
else
	$VPNHOME/busybox udhcpc -t 3 -n -q -i $1 -O msstaticroutes -s $VPNHOME/default.script;if [ ! $? -eq 0 ]; then ifconfig $1 down up; fi
fi
